semantic.icon = {};

// ready event
semantic.icon.ready = function() {

  // selector cache
  var
    $grid         = $('.ui.five.column.doubling.grid'),
    // alias
    handler
  ;


};


// attach ready event
$(document)
  .ready(semantic.icon.ready)
;